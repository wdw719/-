<?php /*a:3:{s:82:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\b_paslist.html";i:1571618177;s:77:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\main.html";i:1571021813;s:79:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\booter.html";i:1570685722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>乐享博客后台管理</title>
    <link rel="stylesheet" href="http://www.blog.com/static/layui(1)/src/css/layui.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="layui-layout-body"  >
<div class="layui-layout layui-layout-admin">
    <div class="layui-header">
        <div class="layui-logo">乐享博客后台布局</div>
        <!-- 头部区域（可配合layui已有的水平导航） -->
        <ul class="layui-nav layui-layout-left">
            <li class="layui-nav-item"><a href="">控制台</a></li>
            <li class="layui-nav-item"><a href="">商品管理</a></li>
            <li class="layui-nav-item"><a href="">用户</a></li>
            <li class="layui-nav-item">
                <a href="javascript:;">其它系统</a>
                <dl class="layui-nav-child">
                    <dd><a href="">邮件管理</a></dd>
                    <dd><a href="">消息管理</a></dd>
                    <dd><a href="">授权管理</a></dd>
                </dl>
            </li>
        </ul>
        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item"><div id="dateTime"></div></li>
            <li class="layui-nav-item">

                <a href="javascript:;">
                    <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php
            if($data['pid']==0){
                echo $data['alert_name'].$data['work']."您好";
            }
            if($data['pid']==1){
           echo $data['alert_name'].$data['work']."您好";
            }
                          if($data['pid']==2){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==3){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==4){
           echo $data['alert_name'].$data['work']."您好";
            }
?>
                </a>
                <dl class="layui-nav-child">
                    <dd><a href="">基本资料</a></dd>
                    <dd><a href="">安全设置</a></dd>
                </dl>
            </li>
            <li class="layui-nav-item"><a href="/">退了</a></li>
        </ul>
    </div>

    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
            <ul class="layui-nav layui-nav-tree"  lay-filter="test">
                <li class="layui-nav-item ">
                    <a class="" href="/admin">后台管理员列表</a>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">用户管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/bue">用户列表</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="/staff">员工列表</a>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">广告管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/ad">广告添加</a></dd>
                        <dd><a href="/badlist">广告列表</a></dd>
                    </dl>
                </li>

                <li class="layui-nav-item ">
                    <a class="" href="bsen">敏感词管理</a>
                </li>

                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">友情链接管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="blist">友情链接列表</a></dd>
                        <dd><a href="bladd">友情链接添加</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">博文管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/baduit">博文未审核列表</a></dd>
                        <dd><a href="/bpalist">博文审核通过列表</a></dd>
                        <dd><a href="/bsplist">博文审核未通过列表</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item">
                    <a href="javascript:;">评论管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/bdiscu">评论未审核列表</a></dd>
                        <dd><a href="/bclist">评论审核通过列表</a></dd>
                        <dd><a href="/bwlist">评论审核未通过列表</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>

    <div class="layui-body">
        <!-- 内容主体区域 -->
        <div style="padding: 30px;" class="container">

        </div>
    </div>


</div>
<div class="layui-footer">
    <!-- 底部固定区域 -->
    © layui.com - 底部固定区域
</div>
</div>
<script src="http://www.blog.com/static/layui(1)/src/layui.js" src="//layui.hcwl520.com.cn/layui-v2.4.5/layui.js" charset="utf-8"></script>
<script>
    //JavaScript代码区域
    layui.use('element', function(){
        var element = layui.element;

    });
    Date.prototype.format = function (fmt) {
        var o = {
            "y+": this.getFullYear, //年
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds() //秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }
    setInterval("document.getElementById('dateTime').innerHTML = (new Date()).format('yyyy-MM-dd hh:mm:ss');", 1000);

</script>

</body>
</html>
<script >
</script>

<?php
            if($data['pid']==0){
                echo $data['alert_name'].$data['work']."您好";
            }
            if($data['pid']==1){
           echo $data['alert_name'].$data['work']."您好";
            }
                                      if($data['pid']==2){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==3){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==4){
           echo $data['alert_name'].$data['work']."您好";
            }
?>
<!---->
<div class="layui-body"  >
    <!-- 博文未审核列表 -->
    <div style="padding: 90px; margin-left: 0px;" class="container">
        <table id="demo" class="table ">
            <tr>
                <td>ID</td>
                <td ><p style="margin-left: 15px;">博文标题</p></td>
                <td><p style="margin-left: 30px;">博文作者</p></td>
                <td>博文简介</td>
            </tr>
            <?php if(is_array($red) || $red instanceof \think\Collection || $red instanceof \think\Paginator): $i = 0; $__LIST__ = $red;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
            <tr>
                <td><?php echo htmlentities($vo['b_id']); ?></td>
                <td><p style="margin-left: 10px;"><?php echo htmlentities($vo['b_title']); ?></p></td>
                <td><?php echo htmlentities($vo['b_author']); ?></td>
                <td><?php echo htmlentities($vo['b_digset']); ?></td>
            </tr>
            <?php endforeach; endif; else: echo "" ;endif; ?>
        </table>
        <div style="margin-left: 690px;"><?php echo $red; ?></div>
    </div>
</div>
</div>
  
  <div class="layui-footer">

  </div>  
</div>

<script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;
  
});
</script>
<script type="text/javascript">
        var in_1 = document.getElementById('input');
        function showTime(){
            var date = new Date();
            var week = date.getDay();
            var weekday;
            switch(week){
                case 0: weekday = '星期天';break;
                case 1: weekday = '星期一';break;
                case 2: weekday = '星期二';break;
                case 3: weekday = '星期三';break;
                case 4: weekday = '星期四';break;
                case 5: weekday = '星期五';break;
                case 6: weekday = '星期六';break;
            }
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            var hour = date.getHours();
            var minute = date.getMinutes();
            var second = date.getSeconds();
            var in_1 = document.getElementById('input');
            in_1.value = year + '年' + month + "月" + day + '日'+' ' + weekday + ' ' + hour + ':' + minute + ':' + second;
            setTimeout(showTime,1000);
        }
        showTime();
    </script>
</body>
</html>
