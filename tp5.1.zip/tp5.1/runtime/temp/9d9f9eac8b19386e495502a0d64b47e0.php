<?php /*a:1:{s:84:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_register.html";i:1571138317;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>博客注册</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <style>
        .abc:hover{
            border-bottom: 2px solid blue;
        }
    </style>
</head>
<body  style=" background: url(http://www.blog.com/login.png) no-repeat center center fixed; background-size: 100%;">

<div style="width:1000px;height:600px;padding: 100px 400px; margin-bottom: 40px;">
    <div style="background-color: white; width: 450px; height: 450px; margin-bottom: 360px;">
        <table  style="text-align:  center;width:400px; height: 80px; background-color:white ">
            <tr>
                <td><a href="/login" style="text-decoration: none;color:black;font-size: 20px;font-weight: 200;"><span class="abc">博客登录</span></a>
                </td><td >|</td><td><a href="/reg" style="text-decoration: none;color:black;font-size: 20px;font-weight: 200;"><span class="abc">博客注册</span></a></td>
            </tr>
        </table>
        <hr>
        <form action="/regdo" method="post">

                <input style="float: left;width: 260px;margin-left: 60px;" type="email" class="form-control" id="email" placeholder="请输入QQ邮箱账号" name="b_email"><span id="emails" style="float: left;margin-top: 8px; margin-left: 3px;"></span>

                <input style="float: left;width: 260px;margin-left: 60px;margin-top: 10px;" type="text" class="form-control" id="phone" name="b_phone" placeholder="请输入手机号" maxlength="11"><span id="phone1" style="float: left;margin-top: 8px; margin-left: 3px;"></span>


                <input style="float: left;width: 260px;margin-left: 60px;margin-top: 10px;" type="text" class="form-control" id="user" name="b_logname" placeholder="请输入登录名称"><span id="user1" style="float: left;margin-top: 8px; margin-left: 3px;"></span>


                <input style="float: left;width: 260px;margin-left: 60px;margin-top: 10px;" type="text" class="form-control" id="s_user" name="b_showname" placeholder="请输入显示名称"><span id="s_users" style="float: left;margin-top: 8px; margin-left: 3px;"></span>


                <input  type="password" class="form-control" style="float: left;width: 260px;margin-left: 60px;margin-top: 10px;" name="b_password" id="pwd" placeholder="请输入密码"><span id="pwds" style="float: left;margin-top: 8px; margin-left: 3px;"></span>


                <input type="password" class="form-control" style="float: left;width: 260px;margin-left: 60px;margin-top: 10px;" id="repwd" onkeyup="validate()"  placeholder="请再次确认密码"><span id="repwds" style="float: left;margin-top: 8px; margin-left: 3px;"></span>

            <button type="submit" class="btn btn-success bts" style="width: 260px; margin-left: 60px;margin-top: 10px;">注册</button>
        </form>

    </div>
</div>
</body>
</html>
<script></script>
<script>
    $("#email").blur(function () {
        //验证qq邮箱
        var qq_email=/^\d{5,}@qq(\.)com$/
        var email=$(this).val()
        if(email==''){
            $("#emails").html("QQ邮箱不能为空");
            $("#emails").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(qq_email.test(email)){
                $("#emails").html("QQ邮箱格式正确");
                $("#emails").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#emails").html("QQ邮箱格式不正确");
                $("#emails").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }

    })
    $("#phone").blur(function () {
        //验证手机号，1开头，第二位是3或5或8
        var phones=/^1[3,5,8]\d{9}$/
        var phone=$(this).val()
        if(phone==''){
            $("#phone1").html("手机号不能为空");
            $("#phone1").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(phones.test(phone)){
                $("#phone1").html("手机号正确");
                $("#phone1").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#phone1").html("手机号格式不对");
                $("#phone1").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }
    })
    //用户名限制
    $("#user").blur(function () {
        var users=/^[\u4e00-\u9fa5]{3,20}$/
        var user=$(this).val()
        if(user==""){
            $("#user1").html("登录名称不能为空");
            $("#user1").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(users.test(user)){
                $("#user1").html("登录名称正确");
                $("#user1").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#user1").html("登录名为3-30位");
                $("#user1").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }

    })
//显示名称
    $("#s_user").blur(function () {
        var s_user1=/^[\u4e00-\u9fa5]{3,20}$/
        var s_user=$(this).val()
        if(s_user==""){
            $("#s_users").html("显示名称不能为空-30位");
            $("#s_users").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(s_user1.test(s_user)){
                $("#s_users").html("显示名称正确");
                $("#s_users").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#s_users").html("显示名称为3-30位");
                $("#s_users").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }

    })


    $("#pwd").blur(function () {
        var pwd_d=/^\w{6,30}$/
        var pwdc=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{6,30}$/
        var pwd=$(this).val()

        if(pwd==""){
            $("#pwds").html("密码不能为空");
            $("#pwds").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(pwd_d.test(pwd)){
                if(pwdc.test(pwd)){
                    $("#pwds").html("密码正确");
                    $("#pwds").css("color","green");
                    $(".bts").removeAttr("disabled");
                }else{
                    $("#pwds").html("密码格式不正确");
                    $("#pwds").css("color","red");
                    $(".bts").attr("disabled","disabled");
                }
            }else{
                alert("密码必须在6-30位并且不能有字符")
            }
        }
    })
    //确认密码
    function validate(){
        var pwd=$("#pwd").val()
        var pwd1 =$("#repwd").val();
        if(pwd == pwd1){
            $("#repwds").html("两次密码相同");
            $("#repwds").css("color","green");
            $(".bts").removeAttr("disabled");
        }else{
            $("#repwds").html("两次密码不相同");
            $("#repwds").css("color","red");
            $(".bts").attr("disabled","disabled");
        }
    }
</script>