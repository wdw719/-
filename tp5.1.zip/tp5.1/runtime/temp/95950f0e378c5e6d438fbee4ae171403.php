<?php /*a:3:{s:80:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\ad_list.html";i:1570688496;s:79:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\b_rbac.html";i:1570688898;s:79:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\booter.html";i:1570685722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
  <title>乐享博客后台管理</title>
  <link rel="stylesheet" href="http://www.blog.com/static/layui(1)/src/css/layui.css">
</head>
<body class="layui-layout-body">
  <div class="layui-layout layui-layout-admin">
    <div class="layui-header">
      <div class="layui-logo">乐享博客后台布局</div>
      <!-- 头部区域（可配合layui已有的水平导航） -->
      <ul class="layui-nav layui-layout-left">
        <li class="layui-nav-item"><a href="">控制台</a></li>
        <li class="layui-nav-item"><a href="">商品管理</a></li>
        <li class="layui-nav-item"><a href="">用户</a></li>
        <li class="layui-nav-item">
          <a href="javascript:;">其它系统</a>
          <dl class="layui-nav-child">
            <dd><a href="">邮件管理</a></dd>
            <dd><a href="">消息管理</a></dd>
            <dd><a href="">授权管理</a></dd>
          </dl>
        </li>
      </ul>
      <ul class="layui-nav layui-layout-right">
        <li class="layui-nav-item">
          <a href="javascript:;">
            <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
            <?php echo $data['alert_name']."您好"; ?>
          </a>
          <dl class="layui-nav-child">
            <dd><a href="">基本资料</a></dd>
            <dd><a href="">安全设置</a></dd>
          </dl>
        </li>
        <li class="layui-nav-item"><a href="/">退了</a></li>
      </ul>
    </div>

    <div class="layui-side layui-bg-black">
      <div class="layui-side-scroll">
        <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
        <ul class="layui-nav layui-nav-tree"  lay-filter="test">
          <li class="layui-nav-item layui-nav-itemed">
            <a class="" href="javascript:;">后台管理员</a>
            <dl class="layui-nav-child">
              <dd><a href="adlist">管理员列表</a></dd>
            </dl>
          </li>
          <li class="layui-nav-item layui-nav-itemed">
            <dl class="layui-nav-child">
              <dd><a href="articles.html">用户列表</a></dd>
            </dl>
          </li>

          <li class="layui-nav-item layui-nav-itemed">
            <a class="" href="javascript:;">广告管理</a>
            <dl class="layui-nav-child">
              <dd><a href="adverts.html">广告添加</a></dd>
              <dd><a href="adverts_add.html">广告列表</a></dd>
            </dl>
          </li>
          <li class="layui-nav-item layui-nav-itemed">
            <a class="" href="admin_users.html">敏感词管理</a>
          </li>

          <li class="layui-nav-item layui-nav-itemed">
            <a class="" href="javascript:;">友情链接管理</a>
            <dl class="layui-nav-child">
              <dd><a href="categories.html">友情链接列表</a></dd>
              <dd><a href="categories_add.html">友情链接添加</a></dd>
            </dl>
          </li>
          <li class="layui-nav-item layui-nav-itemed">
            <a class="" href="javascript:;">博文管理</a>
            <dl class="layui-nav-child">
              <dd><a href="site_settings.html">博文未审核列表</a></dd>
              <dd><a href="site_settings_add.html">博文审核通过列表</a></dd>
              <dd><a href="site_settings_add.html">博文审核未通过列表</a></dd>
            </dl>
          </li>
          <li class="layui-nav-item">
            <a href="javascript:;">评论管理</a>
            <dl class="layui-nav-child">
              <dd><a href="advert_positions.html">评论未审核列表</a></dd>
              <dd><a href="advert_positions_add.html">评论审核通过列表</a></dd>
              <dd><a href="advert_positions_add.html">评论审核未通过列表</a></dd>
            </dl>
          </li>
          <!--<li class="layui-nav-item"><a href="">云市场</a></li>-->
          <!--<li class="layui-nav-item"><a href="">发布商品</a></li>-->
        </ul>
      </div>
    </div>

    <div class="layui-body">
      <!-- 内容主体区域 -->
      <div style="padding: 15px;">
        <table id="demo">1</table>
      </div>
    </div>

    <div class="layui-footer">
      <!-- 底部固定区域 -->
      © layui.com - 底部固定区域
    </div>
  </div>
  <script src="http://www.blog.com/static/layui(1)/src/layui.js" src="//layui.hcwl520.com.cn/layui-v2.4.5/layui.js" charset="utf-8"></script>
  <script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;

});
</script>

</body>
</html>

<?php echo $data['alert_name']."您好"; ?>
<div class="container" style="margin-top: 10px;">
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>账号</th>
            <th>角色</th>
            <th>手机号</th>
            <th>职位</th>
            <th>部门</th>
            <th>创建时间</th>
            <th>修改时间</th>
            <th>操作</th>
        </tr>


    </table>

</div>
<script>
    $('.del').click(function(){
        var id = $(this).parents('tr').attr('data-id');
        var that = $(this)
        // alert(id)
        $.ajax({
            url:"/tp5.1/public/adminDel",
            type:"post",
            dataType:"json",
            data: {
                id:id
            },
            success: function(e){
                if(e.status){
                    alert(e.msg)
                    that.parents('tbody').remove();
                }
            }
        })
    })
</script>
</div>
  
  <div class="layui-footer">

  </div>  
</div>

<script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;
  
});
</script>
<script type="text/javascript">
        var in_1 = document.getElementById('input');
        function showTime(){
            var date = new Date();
            var week = date.getDay();
            var weekday;
            switch(week){
                case 0: weekday = '星期天';break;
                case 1: weekday = '星期一';break;
                case 2: weekday = '星期二';break;
                case 3: weekday = '星期三';break;
                case 4: weekday = '星期四';break;
                case 5: weekday = '星期五';break;
                case 6: weekday = '星期六';break;
            }
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            var hour = date.getHours();
            var minute = date.getMinutes();
            var second = date.getSeconds();
            var in_1 = document.getElementById('input');
            in_1.value = year + '年' + month + "月" + day + '日'+' ' + weekday + ' ' + hour + ':' + minute + ':' + second;
            setTimeout(showTime,1000);
        }
        showTime();
    </script>
</body>
</html>