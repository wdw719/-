<?php /*a:3:{s:78:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\b_add.html";i:1570877367;s:77:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\main.html";i:1570881759;s:79:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/index/view\blog\booter.html";i:1570685722;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>乐享博客后台管理</title>
    <link rel="stylesheet" href="http://www.blog.com/static/layui(1)/src/css/layui.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="layui-layout-body"  >
<div class="layui-layout layui-layout-admin">
    <div class="layui-header">
        <div class="layui-logo">乐享博客后台布局</div>
        <!-- 头部区域（可配合layui已有的水平导航） -->
        <ul class="layui-nav layui-layout-left">
            <li class="layui-nav-item"><a href="">控制台</a></li>
            <li class="layui-nav-item"><a href="">商品管理</a></li>
            <li class="layui-nav-item"><a href="">用户</a></li>
            <li class="layui-nav-item">
                <a href="javascript:;">其它系统</a>
                <dl class="layui-nav-child">
                    <dd><a href="">邮件管理</a></dd>
                    <dd><a href="">消息管理</a></dd>
                    <dd><a href="">授权管理</a></dd>
                </dl>
            </li>
        </ul>
        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item"><div id="dateTime"></div></li>
            <li class="layui-nav-item">

                <a href="javascript:;">
                    <img src="http://t.cn/RCzsdCq" class="layui-nav-img">
                    <?php
            if($data['pid']==0){
                echo $data['alert_name'].$data['work']."您好";
            }
            if($data['pid']==1){
           echo $data['alert_name'].$data['work']."您好";
            }
                          if($data['pid']==2){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==3){
           echo $data['alert_name'].$data['work']."您好";
            }
                        if($data['pid']==4){
           echo $data['alert_name'].$data['work']."您好";
            }
?>
                </a>
                <dl class="layui-nav-child">
                    <dd><a href="">基本资料</a></dd>
                    <dd><a href="">安全设置</a></dd>
                </dl>
            </li>
            <li class="layui-nav-item"><a href="/">退了</a></li>
        </ul>
    </div>

    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll">
            <!-- 左侧导航区域（可配合layui已有的垂直导航） -->
            <ul class="layui-nav layui-nav-tree"  lay-filter="test">
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">后台管理员</a>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">用户管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/bue">用户列表</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="/staff">员工列表</a>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">广告管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="/ad">广告添加</a></dd>
                        <dd><a href="/adlist">广告列表</a></dd>
                    </dl>
                </li>

                <li class="layui-nav-item ">
                    <a class="" href="admin_users.html">敏感词管理</a>
                </li>

                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">友情链接管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="categories.html">友情链接列表</a></dd>
                        <dd><a href="categories_add.html">友情链接添加</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item ">
                    <a class="" href="javascript:;">博文管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="site_settings.html">博文未审核列表</a></dd>
                        <dd><a href="site_settings_add.html">博文审核通过列表</a></dd>
                        <dd><a href="site_settings_add.html">博文审核未通过列表</a></dd>
                    </dl>
                </li>
                <li class="layui-nav-item">
                    <a href="javascript:;">评论管理</a>
                    <dl class="layui-nav-child">
                        <dd><a href="advert_positions.html">评论未审核列表</a></dd>
                        <dd><a href="advert_positions_add.html">评论审核通过列表</a></dd>
                        <dd><a href="advert_positions_add.html">评论审核未通过列表</a></dd>
                    </dl>
                </li>
            </ul>
        </div>
    </div>

    <div class="layui-body">
        <!-- 内容主体区域 -->
        <div style="padding: 30px;" class="container">

        </div>
    </div>


</div>
<div class="layui-footer">
    <!-- 底部固定区域 -->
    © layui.com - 底部固定区域
</div>
</div>
<script src="http://www.blog.com/static/layui(1)/src/layui.js" src="//layui.hcwl520.com.cn/layui-v2.4.5/layui.js" charset="utf-8"></script>
<script>
    //JavaScript代码区域
    layui.use('element', function(){
        var element = layui.element;

    });
    Date.prototype.format = function (fmt) {
        var o = {
            "y+": this.getFullYear, //年
            "M+": this.getMonth() + 1, //月份
            "d+": this.getDate(), //日
            "h+": this.getHours(), //小时
            "m+": this.getMinutes(), //分
            "s+": this.getSeconds() //秒
        };
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));
        for (var k in o)
            if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));
        return fmt;
    }
    setInterval("document.getElementById('dateTime').innerHTML = (new Date()).format('yyyy-MM-dd hh:mm:ss');", 1000);

</script>

</body>
</html>
<script >
</script>

<?php
            if($data['pid']==0){
                echo $data['alert_name'].$data['work']."您好";
            }
            if($data['pid']==1){
           echo $data['alert_name'].$data['work']."您好";
            }
?>
<!--添加管理员-->
<div class="layui-body" style="background:lightskyblue ">
    <!-- 内容主体区域 -->
    <div style="padding: 50px; margin-left: 260px;" class="container">
        <form action="/baddo" method="post">
            <div class="container bts">
                <h2>添加管理员</h2>
        <!--添加管理员-->
                <div class="form-group col-lg-3">
                        <label >账号:</label>
                        <td class="b"> <input type="email" id="email" name="b_username" class="form-control" ></td>
                        <p id="emails"></p>

                    <tr >
                        <td ><label >手机号:</label></td>
                        <td class="p"><input type="text" id="phone"  maxlength="11" name="phone" class="form-control" ></td>
                        <p id="phone1"></p>
                    </tr>

                    <tr >
                        <td class="d"><label >显示名称:</label></td>
                        <input type="text" id="s_user"  name="alert_name" class="form-control" ></td><p id="s_users" style="margin-top: 20px;"></p>
                    </tr>

                    <tr >
                        <td ><label >职位:</label></td>
                        <br>
                        <select name="work" id=""  style="width:200px;height:25px">
                            <?php if(is_array($res) || $res instanceof \think\Collection || $res instanceof \think\Paginator): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($vo['work']); ?>" ><?php echo htmlentities($vo['work']); ?></option>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </tr>
                    <br>

                    <tr >
                        <td ><label >部门:</label></td>
                        <br>
                        <select name="section" id=""  style="width:200px;height:25px">
                            <?php if(is_array($res) || $res instanceof \think\Collection || $res instanceof \think\Paginator): $i = 0; $__LIST__ = $res;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($vo['section']); ?>" ><?php echo htmlentities($vo['section']); ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </tr>
                    <br>

                    <tr >
                        <td ><label >密码:</label></td>
                        <input type="password" id="pwd" name="b_password" class="form-control"  maxlength="30" minlength="6"></td>
                        <p id="pwds"></p>
                    </tr>
                    <tr >
                        <td ><label >确认密码:</label></td>
                        <input type="password" id="repwd"  onkeyup="validate()" class="form-control" ></td><p id="repwds"></p>
                    </tr>
                    <br>
                    <tr >
                        <input type="submit" value="新增管理员" class="btn btn-success btn-lg btn-block bts" >
                    </tr>
                </div>

            </div>
        </form>
    </div>
</div>
<script src="http://www.0.com/jquery.js"></script>
<script>
    $("#email").blur(function () {
        //验证qq邮箱
        var qq_email=/^\d{5,}@qq(\.)com$/
        var email=$(this).val()
        if(email==''){
            $("#emails").html("QQ邮箱不能为空");
            $("#emails").css("color","red");
            $(".bts").attr("disabled","disabled")
        }else{
            if(qq_email.test(email)){
                $("#emails").html("QQ邮箱格式正确");
                $("#emails").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#emails").html("QQ邮箱格式不正确");
                $("#emails").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }

    })
    $("#phone").blur(function () {
        //验证手机号，1开头，第二位是3或5或8
        var phones=/^1[3,5,8]\d{9}$/
        var phone=$(this).val()
        if(phone==''){
            $("#phone1").html("手机号不能为空");
            $("#phone1").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(phones.test(phone)){
                $("#phone1").html("手机号正确");
                $("#phone1").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#phone1").html("手机号格式不正确");
                $("#phone1").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }
    })

    $("#s_user").blur(function () {
        var s_user1=/^[\u4e00-\u9fa5]{3,20}$/
        var s_user=$(this).val()
        if(s_user==""){
            $("#s_users").html("显示名称不能为空");
            $("#s_users").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(s_user1.test(s_user)){
                $("#s_users").html("显示名称正确");
                $("#s_users").css("color","green");
                $(".bts").removeAttr("disabled");
            }else{
                $("#s_users").html("显示名称必须为3-30位");
                $("#s_users").css("color","red");
                $(".bts").attr("disabled","disabled");
            }
        }

    })


    $("#pwd").blur(function () {
        var pwd_d=/^\w{6,30}$/
        var pwdc=/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[^]{6,30}$/
        var pwd=$(this).val()

        if(pwd==""){
            $("#pwds").html("密码不能为空");
            $("#pwds").css("color","red");
            $(".bts").attr("disabled","disabled");
        }else{
            if(pwd_d.test(pwd)){
                if(pwdc.test(pwd)){
                    $("#pwds").html("密码正确");
                    $("#pwds").css("color","green");
                    $(".bts").removeAttr("disabled");
                }else{
                    $("#pwds").html("密码格式不正确");
                    $("#pwds").css("color","red");
                    $(".bts").attr("disabled","disabled");
                }
            }else{
                alert("密码必须在6-30位并且不能有字符")
            }
        }
    })
    //确认密码
    function validate(){
        var pwd=$("#pwd").val()
        var pwd1 =$("#repwd").val();
        if(pwd == pwd1){

            $("#repwds").html("两次密码相同");
            $("#repwds").css("color","green");
            $(".bts").removeAttr("disabled");
        }else{
            $("#repwds").html("两次密码不相同");
            $("#repwds").css("color","red");
            $(".bts").attr("disabled","disabled");
        }
    }
</script>
</div>
  
  <div class="layui-footer">

  </div>  
</div>

<script>
//JavaScript代码区域
layui.use('element', function(){
  var element = layui.element;
  
});
</script>
<script type="text/javascript">
        var in_1 = document.getElementById('input');
        function showTime(){
            var date = new Date();
            var week = date.getDay();
            var weekday;
            switch(week){
                case 0: weekday = '星期天';break;
                case 1: weekday = '星期一';break;
                case 2: weekday = '星期二';break;
                case 3: weekday = '星期三';break;
                case 4: weekday = '星期四';break;
                case 5: weekday = '星期五';break;
                case 6: weekday = '星期六';break;
            }
            var year = date.getFullYear();
            var month = date.getMonth() + 1;
            var day = date.getDate();
            var hour = date.getHours();
            var minute = date.getMinutes();
            var second = date.getSeconds();
            var in_1 = document.getElementById('input');
            in_1.value = year + '年' + month + "月" + day + '日'+' ' + weekday + ' ' + hour + ':' + minute + ':' + second;
            setTimeout(showTime,1000);
        }
        showTime();
    </script>
</body>
</html>
