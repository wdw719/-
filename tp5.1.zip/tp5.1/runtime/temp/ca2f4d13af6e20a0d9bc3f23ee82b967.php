<?php /*a:1:{s:80:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_zpwd.html";i:1571225664;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>找回密码</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body style=" background: url(http://www.blog.com/login.png) no-repeat center center fixed; background-size: 100%;">
<div style="width:1000px;height:600px;padding: 150px 400px; margin-bottom: 40px;">
    <div style="background-color: white; width: 450px; height: 240px; margin-bottom: 360px;">
        <table  style="text-align:  center;width:400px; height: 80px; background-color:white ">
            <tr>
                <td><a href="" style="text-decoration: none;color:black;font-size: 20px;font-weight: 200;margin-left: 40px;"><span class="abc">找回密码</span></a>
            </tr>
        </table>
        <hr>
        <form action="/bxpwd" method="post" >
            <input type="hidden" name="id" value="<?php echo $users['id']?>">
            <input type="hidden" name="b_email" value="<?php echo $users['b_email']?>">
            <input type="hidden" name="code" value="<?php echo $code['code']?>">
            <div class="form-group col-lg-10" style="margin-left: 40px;">
                <input style="" type="password" class="form-control" name="b_password" id="" placeholder="请输入要修改的密码">
            </div>
            <button type="submit" class="btn btn-success " style="width: 300px; margin-left: 75px;">修改密码</button>
        </form>

    </div>
</div>
</body>
</html>