<?php /*a:1:{s:77:"D:\phpstudy2018\PHPTutorial\WWW\tp5.1\application/index/view\login\lists.html";i:1567211191;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<?php foreach($data4 as $key=>$vo): ?>
    <li><?php echo htmlentities($vo['powername']); if($vo['child']): foreach($vo['child'] as $key => $vv): ?>
        <ul>
            <li><a href=""><?php echo htmlentities($vv['powername']); ?></a>
                <?php if($vv['child']): foreach($vv['child'] as $key => $vvv): ?>
                 <ul>
                     <li><a href=""><?php echo htmlentities($vvv['powername']); ?></a></li>
                 </ul>
                <?php endforeach; endif; ?>
            </li>


        </ul>
        <?php endforeach; endif; ?>



    </li>



<?php endforeach; ?>
</body>
</html>