<?php /*a:1:{s:76:"D:\phpstudy2018\PHPTutorial\WWW\tp5.1\application/index/view\login\list.html";i:1567163351;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
  <table>
      <tr>
          <td>大哥</td>
          <td></td>
          <td></td>
      </tr>
      <tr>
          <td></td>
          <td></td>
          <td></td>
      </tr>
      
  </table>
</body>
</html>