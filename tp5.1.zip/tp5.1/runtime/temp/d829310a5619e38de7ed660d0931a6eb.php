<?php /*a:1:{s:83:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_rewrite.html";i:1571376636;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>撰写博文</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <script type="text/javascript" src="http://www.blog.com/static/utf8-php/ueditor.config.js"></script>
    <script type="text/javascript" src="http://www.blog.com/static/utf8-php/ueditor.all.js"></script>
</head>
<body><h4 style="margin-left: 20px;">撰写新的博客</h4>
<div style="margin-left: 80px;">博文标题<input type="text" id="title" style="width: 700px;height: 20px;">
    <br><br>博文择要 <input type="text" id="digset" style="width: 500px;height: 20px;">
</div>
<!--<div style="margin-top: 20px;margin-left: 100px;">博文正文</div>-->
<div style="margin-left: 140px; margin-top: 20px;width: 900px; "><script   id="container" name="content" type="text/plain" ></script></div>

<div style="margin-top: 30px;margin-left: 470px;">所有人可见&nbsp;<input type="radio" name="sta" value="1" >仅自己可见 <input type="radio" name="sta" value="0" ></div>
<div style="margin-left: 500px;margin-top: 20px;"> <button onclick="getContentTxt()"  class="btn" >发布博文</button></div>
<!-- 实例化编辑器 -->
<script type="text/javascript">
    var ue = UE.getEditor('container');
    //获取内容
    function getContentTxt() {
        var arr = [];
        arr.push(UE.getEditor('container').getContentTxt());
        var regExp = /&nbsp;/g;
        var title=$("#title").val()//文章标题
        var digset=$("#digset").val()//文章择要
        var sta=$('input[name="sta"]:checked').val();
        var d=$('input[name="sta"]:checked').val()
        if(d==undefined){
            alert('您的还没有选择是否公开');return;
        }
        //ajax请求
        $.ajax({
            url:'/bwrite',
            type:'post',
            dataType:'json',
            data:{b_title:title,b_digset:digset,b_public:sta,b_text:arr},
            success:function (e) {
                if(e.code==200){
                    alert(e.msg)
                    location.href='/'
                }else{
                    alert(e.msg)
                    location.href='/write'
                }
            }

        })
    }
</script>

</body>
</html>

