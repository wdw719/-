<?php /*a:1:{s:77:"D:\phpstudy2018\PHPTutorial\WWW\tp5.1\application/index/view\login\login.html";i:1567150204;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
<form action="Login/login" method="post">
        <table>
            <tr>
                <td>用户名</td>
                <td><input type="text" name="username"></td>
            </tr>
            <tr>
                <td>密码</td>
                <td><input type="password" name="pwd"></td>
            </tr>
            <tr>
                <td></td>
                <td><input type="submit" value="登陆"></td>
            </tr>

        </table>
</form>

</body>
</html>