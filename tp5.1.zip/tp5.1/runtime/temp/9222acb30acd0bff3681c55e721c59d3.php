<?php /*a:1:{s:87:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_blogcontent.html";i:1571383526;}*/ ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Material Portfolio Template Demo</title>
    <meta name="description" content="Demo of Material design portfolio template"/>
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="http://www.blog.com/static/qiantai/styles/main.css" rel="stylesheet">
    <style>
        .abc:hover{
            border-bottom: 2px solid yellow;
        }
        .imd{
            border-radius: 75%;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }
        .im{
            border-radius: 75%;
            background: url(http://www.blog.com/wlogin.png) 50% no-repeat;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }
        .site-logo {
            border-radius: 50%;
            background: url(http://www.blog.com/wlogin.png) 50% no-repeat;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }

    </style>
</head>
<body id="top">
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header"><a href="/write" id="contact-button" class="mdl-button mdl-button--fab mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--accent mdl-color-text--accent-contrast mdl-shadow--4dp"><i class="material-icons">mail</i></a>
    <header class="mdl-layout__header mdl-layout__header--waterfall site-header">
        <div class="mdl-layout__header-row site-logo-row"><span class="mdl-layout__title">
     <?php if(empty($name)): ?><a href="#"><div class="site-logo"><img src="http://www.blog.com/wlogin.png" alt="" style="width: 120px;height: 120px;border-radius: 50%;"></div></a> <span class="site-description" style="margin-top: 10px;">未登录</span>的点点滴滴多地方辅导费</span></div><?php else: ?>
        <a href="/bimg?id=<?php echo htmlentities($name['id']); ?>"><div class="site-logo">
            <?php if(empty($up['b_pic'])): ?> <img src="http://www.blog.com/wlogin.png" alt="" style="width: 120px;height: 120px;border-radius: 50%;"><?php else: ?>
            <img src="<?php echo htmlentities($up['b_pic']); ?>" alt="" style="width: 120px;height: 120px;border-radius: 50%;"><?php endif; ?>
        </div></a>昵称：<?php echo htmlentities($up['b_showname']); ?><span class="site-description"></span>反反复复付</span></div><?php endif; ?>
<!--<a href="#"><div class="site-logo"><img src="<?php echo htmlentities($name['b_pic']); ?>" alt="" style="width: 120px;height: 120px;border-radius: 50%;"></div></a> <span class="site-description" style="margin-top: 10px;"><?php echo htmlentities($name['b_showname']); ?></span>的点点滴滴多地方辅导费</span></div>-->
        <div class="mdl-layout__header-row site-navigation-row mdl-layout--large-screen-only">
            <nav class="mdl-navigation mdl-typography--body-1-force-preferred-font">
                <a class="mdl-navigation__link" href="about.html">我的博文</a>
                <a class="mdl-navigation__link"  href="contact.html">我的博文</a>
                <a class="mdl-navigation__link" href="contact.html">我的收藏</a>
                <a class="mdl-navigation__link" href="contact.html">我的博文</a>
                <a class="mdl-navigation__link" href="contact.html"><span class="abc">邮箱设置</span></a>
                <a class="abc" href="/login" style="text-decoration: none;color: white;font-size: 14px;">登录</a> &nbsp; | &nbsp;
                <a class="abc" style="text-decoration: none;color: white;font-size: 14px;" href="/reg">注册</a>            &nbsp; | &nbsp; &nbsp;
                <a class="abc" style="text-decoration: none;color: white;font-size: 14px;" href="/quit">退出</a>
            </nav>
        </div>
    </header>
    <div class="mdl-layout__drawer mdl-layout--small-screen-only">
        <nav class="mdl-navigation mdl-typography--body-1-force-preferred-font"><a class="mdl-navigation__link" href="index.html">Home</a><a class="mdl-navigation__link" href="portfolio.html">Portfolio</a><a class="mdl-navigation__link" href="about.html">About</a><a class="mdl-navigation__link" href="contact.html">Contact</a>
        </nav>
    </div>
    <main class="mdl-layout__content">
        <div class="site-content">
            <div class="container"><div class="mdl-grid site-max-width">

            </div>
                <div class="tlinks">Collect from <a href="http://www.cssmoban.com/"  title="网站模板">网站模板</a></div>
                <section class="section--center mdl-grid site-max-width" style="height: auto;">
                    <div style="width: 1000px;" class="mdl-card mdl-cell mdl-cell--9-col-desktop mdl-cell--6-col-tablet mdl-cell--4-col-phone  mdl-shadow--4dp">
                        <div class="mdl-card__title" >
                            <div><img src="<?php echo htmlentities($blog['b_pic']); ?>" style="width:60px;height: 60px; border-radius: 50%;" alt=""></div>
                            <div>
                                <p style="font-weight: 400; font-size: 14px;" class="mdl-card__title-text"><?php echo htmlentities($blog['b_author']); ?></p>
                                <p style="  font-weight: 400; font-size: 12px;margin-top: 30px" class="mdl-card__title-text"><?php echo htmlentities($blog['b_createtime']); ?></p>
                            </div>
                            <div style="width: 200px;margin-left: 50%">
                                浏览：0 评论：<?php echo htmlentities($blog['b_con']); ?>
                            </div>
                        </div>
                        <div class="mdl-card__actions  mdl-card--border">
                            <div class="mdl-card__supporting-text" >
                                <h2 style="margin-left: 30px; font-weight: 400; margin-bottom: 10px; " class="mdl-card__title-text"><span style="font-size: 25px;"><?php echo htmlentities($blog['b_title']); ?></span></h2>
                                <h5 style="font-weight: 500; font-size: 20px; overflow-y: scroll;"><?php echo htmlentities($blog['b_text']); ?></h5>
                            </div>

                        </div>
                        <div class="mdl-card__actions  mdl-card--border" >
                    </div>
                        <div>
                            <div><?=mb_substr("二、 【妙论女人】女人看重的是男人的明天，男人看重的是女人的今天。真正能使女人成为别人老婆的不是父母，而是年龄。一个女人，倘若得不到异性的爱，就也得不到同性的尊重。女性有两个特点：衣服再多，也觉得自己没衣服;姿色再少，也觉得自己有姿色。试金可以用火，试女人可以用金，试男人可以用女人。

　　三、 人生有太多的不可知，一个念头，一次决定，往往拥有或错过一份缘。选择了爱是因为有缘，而选择了不爱却也是为了缘。守侯着期待与梦想，与不爱的人擦肩，与爱着的人携手。

　　四、 等着别人来爱你，不如自己努力爱自己。人生的路，走走停停是一种闲适，你害怕的越多，那么困难就越多;什么都不怕的时候一切反而没那么难。这世界就是这样，当你把不敢去实现梦想的时候梦想会离你越来越远，当你勇敢地去追梦的时候，一切都会为你让道，尽情的追逐吧。

　　五、 当你能念书时，你念书就是;当你能做事时，你做事就是;当你能恋爱时，你再去恋爱;当你能结婚时，你再去结婚。环境不许可时，强求不来;时机来临时，放弃不得。这便是一个人应有的生活哲学了。

　　六、 缘分就是这样，在我们未曾准备好时，突然袭击。当我们准备面对时，却早已消失了，无论我们如何争取，如何挽留，它总是会毫不留情的离去;只留给我们一丝丝回忆的空间，慢慢的时光也会带走这段美好而又甜蜜的回忆;直到我们丝毫不记得，方可罢休。

　　七、 想对所有的异地恋说的话：或许你现在开始烦她，发现以前她不是这样的。或许你觉得她没你身边的异性朋友优秀，以为自己从一开始爱上她就是一个错误。或许你开始喜欢上别人，却要她面前说自己累了。或许因为家庭原因，让你觉得你么终究要分离。或许你觉得她身上全是缺点，原来爱的人已经走远。或许你觉得自己承受不了孤单寂寞，想要另寻新欢。或许你厌烦她种种，却说不出理由，想要和她分手。或许你正经历着这些迷惑而苦恼的时候，你需要静下心来好好想想你们当初的誓言，自己曾经是多么深爱着她，你们不在乎彼此的缺点选择了在一起，你们不顾家人的反对选择了在一起，你们的朋友羡慕你们，祝福你们，希望你们能够彼此依偎走过一生……回到爱最初的地方，心就会在一起。

　　八、 背叛伤不了你，能伤你的是你太在乎。分手伤不了你，能伤你的是回忆。欺骗伤不了你，能伤你的是希望。没有结局的感情，总会结束;不能拥有的人，总要忘记。你以为感情伤害了你，其实伤到你的，是你自己。所以，做人的最高境界，不是全心全意去爱，而是过好自己人生，让别人来死缠烂打吧!",0,100)?>...</div>
                        <textarea id="con"  placeholder="您有什么想说的吗" style="width: 400px; height: 50px; margin-left: 40px;"  ></textarea>
                            <input type="hidden" data-id="<?php echo htmlentities($blog['id']); ?>" class="id">
                            <input type="hidden" data-ids="<?php echo htmlentities($blog['b_id']); ?>" class="ids">
                            <input type="hidden" data-con="<?php echo htmlentities($blog['b_con']); ?>" class="con">
                        <button class="btn btn-success bts">发表</button></div>
                        <div>
                            <img src="" alt="">
                        </div>

                <!--<section class="section&#45;&#45;center mdl-grid site-max-width">-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                <!--<div class="mdl-card__media">-->
                <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio1.jpg" border="0" alt="">-->
                <!--</div>-->
                <!--<div class="mdl-card__title">-->
                <!--<h2 class="mdl-card__title-text">Rocky Peak</h2>-->
                <!--</div>-->
                <!--<div class="mdl-card__supporting-text">-->
                <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                <!--</div>-->
                <!--</div>-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                <!--<div class="mdl-card__media">-->
                <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio2.jpg" border="0" alt="">-->
                <!--</div>-->
                <!--<div class="mdl-card__title">-->
                <!--<h2 class="mdl-card__title-text">Night Shadow</h2>-->
                <!--</div>-->
                <!--<div class="mdl-card__supporting-text">-->
                <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                <!--</div>-->
                <!--</div>-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                <!--<div class="mdl-card__media">-->
                <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio3.jpg" border="0" alt="">-->
                <!--</div>-->
                <!--<div class="mdl-card__title">-->
                <!--<h2 class="mdl-card__title-text">Sky Reach</h2>-->
                <!--</div>-->
                <!--<div class="mdl-card__supporting-text">-->
                <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                <!--</div>-->
                <!--</div>-->
                <!--</section>-->

                <!--<section class="section&#45;&#45;center mdl-grid site-max-width homepage-portfolio">-->
                <!--<a class="mdl-button mdl-button&#45;&#45;raised mdl-js-button mdl-js-ripple-effect mdl-button&#45;&#45;accent" href="portfolio.html">View Portfolio</a>-->
                <!--</section>-->

                <div class="homepage-footer">
                    <section class="mdl-grid site-max-width">
                        <div class="mdl-cell mdl-card mdl-cell--8-col mdl-cell--4-col-tablet  mdl-shadow--4dp portfolio-card">
                            <div class="mdl-card__title">
                                <h2 class="mdl-card__title-text">Testimonials</h2>
                            </div>
                            <ul class="demo-list-three mdl-list">
                                <li class="mdl-list__item mdl-list__item--three-line">
              <span class="mdl-list__item-primary-content">
                <i class="material-icons mdl-list__item-avatar">person</i>
                <span>Amazing people, always ready to help!</span>
                <span class="mdl-list__item-text-body">
                  Bryan Cranston, CEO, Amazing.com
                </span>
              </span>
                                </li>
                                <li class="mdl-list__item mdl-list__item--three-line">
              <span class="mdl-list__item-primary-content">
                <i class="material-icons  mdl-list__item-avatar">person</i>
                <span>Awesome work, they can do almost anything..</span>
                <span class="mdl-list__item-text-body">
                Aaron Paul, Marketing Lead, Awesome.com
                </span>
              </span>
                                </li>
                            </ul>
                        </div>
                        <div class="demo-card-event mdl-cell mdl-card mdl-shadow--4dp event-card portfolio-card">
                            <div class="mdl-card__title mdl-card--expand">
                                <h4>
                                    Featured event:<br>
                                    Community Meetup
                                    May 24, 2018<br>
                                    7-11pm
                                </h4>
                            </div>
                            <div class="mdl-card__actions mdl-card--border">
                                <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect mdl-button--accent">
                                    Add to Calendar
                                </a>
                                <div class="mdl-layout-spacer"></div>
                                <i class="material-icons">event</i>
                            </div>
                        </div>
                    </section>
                </div></div>
        </div>

        <footer class="mdl-mini-footer">
            <div class="footer-container">
                <div class="mdl-logo">&copy; Unitiled. More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></div>
                <ul class="mdl-mini-footer__link-list">
                    <li><a href="#">Privacy & Terms</a></li>
                </ul>
            </div>
        </footer>
    </main>
    <script src="https://code.getmdl.io/1.3.0/material.min.js" defer></script>
</div>
</body>
</html>
<script type="text/javascript">
    $(".bts").click(function () {
        var con=$("#con").val()
        var id=$(".id").attr('data-id');//用户的id
        var ids=$(".ids").attr('data-ids');//文章的b_id
        var b_con=$(".con").attr('data-con');//评论量

        $.ajax({
            url:'/content',
            data:{id:id,con:con,ids:ids,b_con:b_con},
            type:'post',
            dataType:'json',
            success:function (e) {
                if(e.code==200){
                    alert(e.msg)
                    location.href='/show?id='+id;
                }else{
                    alert(e.msg)
                    location.href='/show?id='+id;return;
                }
            }
        })
    })
</script>