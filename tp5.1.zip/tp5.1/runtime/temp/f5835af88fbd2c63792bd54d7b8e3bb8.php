<?php /*a:1:{s:81:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_login.html";i:1571187302;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>博客登录</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <style>
        .abc:hover{
            border-bottom: 2px solid blue;
        }
    </style>
</head>
<body  style=" background: url(http://www.blog.com/login.png) no-repeat center center fixed; background-size: 100%;">
<div style="width:1000px;height:600px;padding: 150px 400px; margin-bottom: 40px;">
    <div style="background-color: white; width: 450px; height: 300px; margin-bottom: 360px;">
    <table  style="text-align:  center;width:400px; height: 80px; background-color:white ">
        <tr>
            <td><a href="/login" style="text-decoration: none;color:black;font-size: 20px;font-weight: 200;"><span class="abc">博客登录</span></a>
            </td><td >|</td><td><a href="/reg" style="text-decoration: none;color:black;font-size: 20px;font-weight: 200;"><span class="abc">博客注册</span></a></td>
        </tr>
    </table>
        <hr>
    <form action="/logdo" method="post" >
        <div class="form-group col-lg-10" style="margin-left: 40px;">
            <input style="" type="text" class="form-control" name="b_logname" id="" placeholder="请输入登录名称">
        </div>
        <div class="form-group col-lg-10">
            <input type="password" class="form-control" name="b_password" style="margin-left: 40px;" id="" placeholder="请输入密码">
        </div>
        <div class="form-group col-lg-12">
           <div style="margin-left: 180px;"><a href="">忘记密码</a>&nbsp;&nbsp;&nbsp;<a href="">还没有账号?去注册>></a></div>
        </div>
        <button type="submit" class="btn btn-success " style="width: 300px; margin-left: 75px;">登录</button>
    </form>

    </div>
</div>

</body>
</html>