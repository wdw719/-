<?php /*a:1:{s:84:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_manytext.html";i:1571586192;}*/ ?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
       <h2 style="margin-left: 30%;">标题:<?php echo htmlentities($data['b_title']); ?></h2><br><br>
       <span style="margin-left: 10%;">正文</span> <br><br>
      <span style="margin-left: 15%;"><?php echo htmlentities($data['b_text']); ?></span>

</body>
</html>