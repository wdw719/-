<?php /*a:1:{s:80:"E:\phpstudy\PHPTutorial\WWW\share\tp5.1\application/front/view\share\b_reco.html";i:1571655314;}*/ ?>
<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Material Portfolio Template Demo</title>
    <meta name="description" content="Demo of Material design portfolio template"/>
    <link href="https://fonts.googleapis.com/css?family=Roboto:regular,bold,italic,thin,light,bolditalic,black,medium&amp;amp;lang=en" rel="stylesheet">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/jquery@1.12.4/dist/jquery.min.js"></script>
    <link href="http://www.blog.com/static/qiantai/styles/main.css" rel="stylesheet">
    <style>
        .abc:hover{
            border-bottom: 2px solid yellow;
        }
        .imd{
            border-radius: 75%;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }
        .im{
            border-radius: 75%;
            background: url(http://www.blog.com/wlogin.png) 50% no-repeat;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }
        .site-logo {
            border-radius: 50%;
            background: url(http://www.blog.com/wlogin.png) 50% no-repeat;
            background-size: cover;
            height: 120px;
            width: 120px;
            margin: 15px auto;
        }

    </style>
</head>
<body id="top">
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header"><a href="/write" id="contact-button" class="mdl-button mdl-button--fab mdl-js-button mdl-button--raised mdl-js-ripple-effect mdl-color--accent mdl-color-text--accent-contrast mdl-shadow--4dp"><i class="material-icons">mail</i></a>
    <header class="mdl-layout__header mdl-layout__header--waterfall site-header">
        <div class="mdl-layout__header-row site-logo-row"><span class="mdl-layout__title">

               <?php if(empty($name)): ?>
            <a href="#"><div class="site-logo"><img src="http://www.blog.com/wlogin.png" alt="" style="width: 120px;height: 120px;border-radius: 50%;"></div></a> <span class="site-description" style="margin-top: 10px;">未登录</span></span></div>
        <?php else: ?>
        <a href=""><div class="site-logo">
            <?php if(empty($name['b_pic'])): ?>
            <img src="http://www.blog.com/wlogin.png" alt="" style="width: 120px;height: 120px;border-radius: 50%;">
            <?php else: ?>
            <img src="<?php echo htmlentities($name['b_pic']); ?>" alt="" style="width: 120px;height: 120px;border-radius: 50%;"><?php endif; ?>

        </div></a><span style="margin-left: 110px">昵称：<?php echo htmlentities($name['b_showname']); ?></span><span class="site-description">
    </span><p style="margin-left: 60px;"><span style="margin-right: 60px;">关注：<?php echo htmlentities($count); ?></span><span style="margin-right: 60px;">粉丝：<?php echo htmlentities($counts); ?></span>博龄：<?php echo htmlentities($time); ?>天</p></span></div><?php endif; ?>

<div class="mdl-layout__header-row site-navigation-row mdl-layout--large-screen-only" >
    <nav class="mdl-navigation mdl-typography--body-1-force-preferred-font">
        <a class="mdl-navigation__link" href="/home" ><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">首页</span</a>
        <?php if(empty($name)): ?>
        <a class="mdl-navigation__link nameone" href="#"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的博文</span></a>
        <a class="mdl-navigation__link nametwo"  href="#"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的评论</span></a>
        <a class="mdl-navigation__link namethree" href="#"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的收藏</span></a>
        <a class="mdl-navigation__link namefour" href="#"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的推荐</span></a>
        <a class="mdl-navigation__link namefive" href="#"><span class="abc" style=""><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">信息设置</span></span></a>
        <?php else: ?>
        <a class="mdl-navigation__link" href="/home"></a>
        <a class="mdl-navigation__link " href="/myblog"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的博文</span></a>
        <a class="mdl-navigation__link"  href="/mycol"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的评论</span></a>
        <a class="mdl-navigation__link" href="/mycoll"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的收藏</span></a>
        <a class="mdl-navigation__link" href="/reco"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">我的推荐</span></a>
        <a class="mdl-navigation__link" href="/emails"><span class="abc" style="text-decoration: none;color: white;font-size: 14px;">信息设置</span></a>
        <?php endif; ?>


    </nav>
    <a class="abc" href="/login" style="text-decoration: none;color: white;font-size: 14px;">登录</a> &nbsp; | &nbsp;

    <a class="abc" style="text-decoration: none;color: white;font-size: 14px;" href="/reg">注册</a>            &nbsp; | &nbsp; &nbsp;
    <a class="abc" style="text-decoration: none;color: white;font-size: 14px;" href="/quit">退出</a>
</div>
</header>
<div class="mdl-layout__drawer mdl-layout--small-screen-only">
    <nav class="mdl-navigation mdl-typography--body-1-force-preferred-font"><a class="mdl-navigation__link" href="index.html">Home</a><a class="mdl-navigation__link" href="portfolio.html">Portfolio</a><a class="mdl-navigation__link" href="about.html">About</a><a class="mdl-navigation__link" href="contact.html">Contact</a>
    </nav>
</div>
<main class="mdl-layout__content">
    <div class="site-content">
        <div class="container"><div class="mdl-grid site-max-width">
            <section class="section--center mdl-grid site-max-width">
                <?php if(is_array($data) || $data instanceof \think\Collection || $data instanceof \think\Paginator): $i = 0; $__LIST__ = $data;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>

                <div style="width: 1000px;" class="mdl-card mdl-cell mdl-cell--9-col-desktop mdl-cell--6-col-tablet mdl-cell--4-col-phone  mdl-shadow--4dp">
                    <div class="mdl-card__title" >
                        <div><img src="<?php echo htmlentities($name['b_pic']); ?>" style="width:60px;height: 60px; border-radius: 50%;" alt=""></div>
                        <div>
                            <p style="font-weight: 400; font-size: 14px;" class="mdl-card__title-text"><?php echo htmlentities($vo['b_author']); ?></p>
                            <p style="  font-weight: 400; font-size: 12px;margin-top: 30px" class="mdl-card__title-text"><?php echo htmlentities($vo['b_createtime']); ?></p>
                        </div>
                        <div style="width: 400px;margin-left: 45%">
                            浏览：<?php echo htmlentities($vo['b_pv']); ?>&nbsp;推荐数：<?php echo htmlentities($vo['b_zannum']); ?>&nbsp;反对数:<?php echo htmlentities($vo['b_fannums']); ?>&nbsp;被收藏数：<?php echo htmlentities($vo['b_colnum']); ?>
                        </div>
                    </div>
                    <div class="mdl-card__actions  mdl-card--border" >
                        <div class="mdl-card__supporting-text" >
                            <h2 style="margin-left: 30px; font-weight: 400; margin-bottom: 10px; " class="mdl-card__title-text"><span style="font-size: 25px;"><a
                                    href="/show?id=<?php echo htmlentities($vo['b_id']); ?>" style="text-decoration: none;color: lightskyblue;" title="查看全文"><?php echo htmlentities($vo['b_title']); ?></a></span></h2>
                            <h5 style="font-weight: 500; font-size: 20px;"><?php echo htmlentities($vo['b_digset']); ?></h5>
                        </div>
                    </div>
                </div>
                <?php endforeach; endif; else: echo "" ;endif; ?>
            </section>
        </div>
            <div class="tlinks">Collect from <a href="http://www.cssmoban.com/"  title="网站模板">网站模板</a></div>
            <!--<section class="section&#45;&#45;center mdl-grid site-max-width">-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                    <!--<div class="mdl-card__media">-->
                        <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio1.jpg" border="0" alt="">-->
                    <!--</div>-->
                    <!--<div class="mdl-card__title">-->
                        <!--<h2 class="mdl-card__title-text">Rocky Peak</h2>-->
                    <!--</div>-->
                    <!--<div class="mdl-card__supporting-text">-->
                        <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                    <!--</div>-->
                <!--</div>-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                    <!--<div class="mdl-card__media">-->
                        <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio2.jpg" border="0" alt="">-->
                    <!--</div>-->
                    <!--<div class="mdl-card__title">-->
                        <!--<h2 class="mdl-card__title-text">Night Shadow</h2>-->
                    <!--</div>-->
                    <!--<div class="mdl-card__supporting-text">-->
                        <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                    <!--</div>-->
                <!--</div>-->
                <!--<div class="mdl-cell mdl-card mdl-shadow&#45;&#45;4dp portfolio-card">-->
                    <!--<div class="mdl-card__media">-->
                        <!--<img class="article-image" src="http://www.blog.com/static/qiantai/img/portfolio3.jpg" border="0" alt="">-->
                    <!--</div>-->
                    <!--<div class="mdl-card__title">-->
                        <!--<h2 class="mdl-card__title-text">Sky Reach</h2>-->
                    <!--</div>-->
                    <!--<div class="mdl-card__supporting-text">-->
                        <!--Enim labore aliqua consequat ut quis ad occaecat aliquip incididunt. Sunt nulla eu enim irure enim nostrud aliqua consectetur ad consectetur sunt ullamco officia. Ex officia laborum et consequat duis.-->
                    <!--</div>-->
                <!--</div>-->
            <!--</section>-->

            <section class="section--center mdl-grid site-max-width homepage-portfolio">
                <a class="mdl-button mdl-button--raised mdl-js-button mdl-js-ripple-effect mdl-button--accent" href="portfolio.html">View Portfolio</a>
            </section>

            <div class="homepage-footer">
                <section class="mdl-grid site-max-width">
                    <div class="mdl-cell mdl-card mdl-cell--8-col mdl-cell--4-col-tablet  mdl-shadow--4dp portfolio-card">
                        <div class="mdl-card__title">
                            <h2 class="mdl-card__title-text">Testimonials</h2>
                        </div>
                        <ul class="demo-list-three mdl-list">
                            <li class="mdl-list__item mdl-list__item--three-line">
              <span class="mdl-list__item-primary-content">
                <i class="material-icons mdl-list__item-avatar">person</i>
                <span>Amazing people, always ready to help!</span>
                <span class="mdl-list__item-text-body">
                  Bryan Cranston, CEO, Amazing.com
                </span>
              </span>
                            </li>
                            <li class="mdl-list__item mdl-list__item--three-line">
              <span class="mdl-list__item-primary-content">
                <i class="material-icons  mdl-list__item-avatar">person</i>
                <span>Awesome work, they can do almost anything..</span>
                <span class="mdl-list__item-text-body">
                Aaron Paul, Marketing Lead, Awesome.com
                </span>
              </span>
                            </li>
                        </ul>
                    </div>
                    <div class="demo-card-event mdl-cell mdl-card mdl-shadow--4dp event-card portfolio-card">
                        <div class="mdl-card__title mdl-card--expand">
                            <h4>
                                Featured event:<br>
                                Community Meetup
                                May 24, 2018<br>
                                7-11pm
                            </h4>
                        </div>
                        <div class="mdl-card__actions mdl-card--border">
                            <a class="mdl-button mdl-button--colored mdl-js-button mdl-js-ripple-effect mdl-button--accent">
                                Add to Calendar
                            </a>
                            <div class="mdl-layout-spacer"></div>
                            <i class="material-icons">event</i>
                        </div>
                    </div>
                </section>
            </div></div>
    </div>
    <footer class="mdl-mini-footer">
        <div class="footer-container">
            <div class="mdl-logo">&copy; Unitiled. More Templates <a href="http://www.cssmoban.com/" target="_blank" title="模板之家">模板之家</a> - Collect from <a href="http://www.cssmoban.com/" title="网页模板" target="_blank">网页模板</a></div>
            <ul class="mdl-mini-footer__link-list">
                <li><a href="#">Privacy & Terms</a></li>
            </ul>
        </div>
    </footer>
</main>
<script src="https://code.getmdl.io/1.3.0/material.min.js" defer></script>
</div>
</body>
</html>
<script>
    $(".nameone").click(function () {
        alert("您还没有登录")
    })
    $(".nametwo").click(function () {
        alert("您还没有登录")
    })
    $(".namethree").click(function () {
        alert("您还没有登录")
    })
    $(".namefour").click(function () {
        alert("您还没有登录")
    })
    $(".namefive").click(function () {
        alert("您还没有登录")
    })
</script>