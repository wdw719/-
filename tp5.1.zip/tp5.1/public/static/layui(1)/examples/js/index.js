

layui.define(function(exports){
  
  exports('index', {
    title: '模块入口'
  });
});