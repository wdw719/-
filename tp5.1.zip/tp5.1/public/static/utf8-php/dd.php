<?
  $df=$_POST['df'];
//   echo json_encode($df);
 $dd=ltrim($df,"<p>");
echo json_encode($dd)
?>