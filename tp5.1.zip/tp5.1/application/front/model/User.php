<?php

namespace app\front\model;

use think\Model;
use think\Db;
class User extends Model
{
    //用户注册
    public function bReg($bData)
    {
        return Db::table("b_name")->insertGetId($bData);
    }
    //添加code
    public function bCode($code,$time,$uid,$dtime)
    {
        return Db::table("u_code")->insert(['code'=>$code,'b_times'=>$time,'uids'=>$uid,'b_dtime'=>$dtime]);
    }
    //修改用户的状态
    public function bSta()
    {

    }
  //logname登录名称
   public function bUsel($logname)
   {
       return Db::table("b_name")->where('b_logname',$logname)->select();
   }
   //b_showname显示名称
    public function bShow($b_showname)
    {
        return Db::table("b_name")->where('b_showname',$b_showname)->select();
    }
    //查询用户是否被封号
    public function bFel($logname)
    {
        return Db::table("b_name")->where('b_logname',$logname)->find();
    }
    //查看用户是否激活账号
    public function bSj($id)
    {
        return Db::table("u_code")->where('uids',$id)->find();
    }
    //查询状态
    public function bselSta($id){
        return Db::table("u_code")->where('uids',$id)->find();
    }
    //激活账号
    public function bActcode($uid)
    {
        return Db::table("u_code")->update(['b_sta'=>1,'uid'=>$uid]);
    }
    //更新code码
    public function bNewcode($uid,$times,$code)
    {
        return Db::table("u_code")->update(['code'=>$code,'b_sta'=>1,'b_dtime'=>$times,'uid'=>$uid]);
    }

}