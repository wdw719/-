<?php

namespace app\front\model;

use think\Model;
use think\Db;
class User extends Model
{
    //用户注册
    public function bReg($bData)
    {
        return Db::table("b_name")->insertGetId($bData);
    }
    //添加code
    public function bCode($code,$time,$uid,$dtime)
    {
        return Db::table("u_code")->insert(['code'=>$code,'b_times'=>$time,'uids'=>$uid,'b_dtime'=>$dtime]);
    }
  //logname登录名称
   public function bUsel($logname)
   {
       return Db::table("b_name")->where('b_logname',$logname)->select();
   }
   //b_showname显示名称
    public function bShow($b_showname)
    {
        return Db::table("b_name")->where('b_showname',$b_showname)->select();
    }
    //查询用户是否被封号
    public function bFel($logname)
    {
        return Db::table("b_name")->where('b_logname',$logname)->find();
    }
    //查看用户是否激活账号
    public function bSj($id)
    {
        return Db::table("u_code")->where('uids',$id)->find();
    }
    //查询状态
    public function bselSta($id){
        return Db::table("u_code")->where('uids',$id)->find();
    }
    //激活账号
    public function bActcode($uid)
    {
        return Db::table("u_code")->update(['b_sta'=>1,'b_sta'=>1,'uid'=>$uid]);
    }
    //更新code码
    public function bNewcode($uid,$times,$code)
    {
        return Db::table("u_code")->update(['code'=>$code,'b_sta'=>1,'b_dtime'=>$times,'uid'=>$uid]);
    }
    //找回密码
    public function bZpwd($logName)
    {
        return Db::table("b_name")->where('b_logname',$logName)->find();
    }
    //修改密码
    public function bXpwd($id,$pwd)
    {
       return Db::table("b_name")->update(['b_password'=>$pwd,'id'=>$id]);
    }
    public function biMg($imgs,$id)
    {
        return Db::table("b_name")->update(['b_pic'=>$imgs,'id'=>$id]);
    }
    //添加博文
    public function bWblog($data)
    {
       return Db::table("b_text")->insert($data);
    }
    //查询用户
    public function bImgs($id){
        return Db::table("b_name")->where('id',$id)->find();
    }
    //博客列表
    public function bBloglist()
    {
        return Db::table('b_text')
            ->alias('a')
            ->join(['b_name'=>'b'],'a.userid=b.id')
            ->where('a.b_public',1)
            ->where('a.b_sta',1)
            ->order('a.b_createtime desc')
            ->select();
    }
    //博客正文
    public function bBlogcon($id)
    {
        return Db::table('b_text')
            ->alias('a')
            ->join(['b_name'=>'b'],'a.userid=b.id')
            ->where('a.b_id',$id)
            ->find();
    }
    //添加评论内容
    public function bComent($red)
    {
        return Db::table("b_content")->insert($red);
    }
    //修改评论数量
    public function bText($ids,$con)
    {
        return Db::table("b_text")->update(['b_con'=>$con+1,'b_id'=>$ids]);
    }
    //根据时间查询评论内容的最近条数据
    public function bD($id)
    {
        return Db::table('b_content')
            ->where('b_artid',$id)
            ->where('b_sta',1)
            ->order('b_ptime desc')
            ->limit(3)
            ->select();

    }
    //查询全部评论数据
    public function bCd($id)
    {
        return Db::table('b_content')
            ->where('b_artid',$id)
            ->where('b_sta',1)
            ->order('b_ptime desc')
            ->select();
    }
    //查询用户
    public function userInfo($id)
    {
        return Db::table("b_name")->where('id',$id)->find();
    }
    //浏览
    public function  bPv($id,$pv)
    {
        Db::table("b_text")->update(['b_pv'=>$pv+1,'b_id'=>$id]);
    }
    //查询用户信息
    public function bUser($uid)
    {
        return Db::table("b_name")->where('id',$uid)->select();
    }
    public function zanInfo()
    {

    }

    //文章用户关联
    public function bZanart($red)
    {
        return Db::table("b_zan")->insert($red);
    }
    //根据用户查询是否推荐关联表的文章信息
    public function bZnwen($userid)
    {
        return Db::table("b_zan")->where('user_id',$userid)->select();
    }
    public function bZen($id){
        return Db::table("b_zan")->where('wen_id',$id)->select();
    }
    //查询赞的数量
    public function bZn($b_id)
    {
        return Db::table("b_text")->where('b_id',$b_id)->find();
    }

    //修改赞的数量
    public function bUpzan($b_id,$zan_num)
    {
        return Db::table("b_text")->update(['b_zannum'=>$zan_num+1,'b_id'=>$b_id]);
    }

    //查询踩的数量
    public function bCn($b_id)
    {
        return Db::table("b_text")->where('b_id',$b_id)->find();
    }
    //修改踩的数量
    public function bUpcai($b_id,$b_fannums)
    {
        return Db::table("b_text")->update(['b_fannums'=>$b_fannums+1,'b_id'=>$b_id]);
    }
    public function bZa($id)
    {
       return Db::table("b_zan")->where("wen_id",$id)->find();
    }
}