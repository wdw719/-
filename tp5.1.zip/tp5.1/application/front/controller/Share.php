<?php
namespace app\front\controller;

use think\Controller;
use think\facade\Session;
use think\facade\Cookie;
use app\front\model\User;
use think\Db;
class Share extends Controller
{
    //用户注册页面
    public function bRegister()
    {
         return view("b_register");
    }
    //邮箱
    public function bEmail(){
        include "Email.php";
    }
    //用户注册
    public function bRegdo()
    {
        $bData=input("post.");//接受的数据
        $bse=new User();
         $logname=$bData['b_logname'];
         $b_showname=$bData['b_showname'];
        $bsel=$bse->bUsel($logname);
        Session::set('user',$bsel);
        $bShow=$bse->bShow($b_showname);
        if(empty($bsel)){
              if(empty($bShow)){
                  $bData['b_password']=md5($bData['b_password']);//密码加密
                  $bNew=new User();
                  $res =$bNew->bReg($bData);
                  $code=md5(time().rand(1,9999));//用户注册的code码
                  $time=date("Y-m-d:H:i:s",time());//用户注册的时间
                  $uid=$res;//用户id
                  $dtime=date("Y-m-d:H:i:s",time()+60*60*2);//用户登录的有效期
                  if($res){
                      $red=$bNew->bCode($code,$time,$uid,$dtime);     //添加用户code码
                      echo "<script>alert('注册成功');location.href='/login'</script>";;
                  }else{
                      echo "<script>alert('注册成功');location.href='/reg'</script>";;
                  }
              }else{
                  echo "<script>alert('您输入的显示名称已存在');location.href='/reg'</script>";
              }
        }else{
            echo "<script>alert('您输入的登录名称已存在');location.href='/reg'</script>";
        }
    }
    //用户登录页面
    public function bLogin(){
      return view("b_login");
    }
    public function bLogdo()
    {
        $data=input("post.");
        $bNew=new User();
        $logname=$data['b_logname'];
        $res=$bNew->bFel($logname);
        Session::set("bname",$res);//用户信息
       if($res['b_snum']==2){
           echo "<script>alert('您的账号已经被封号了');location.href='/login'</script>";
       }
        if(empty($res)){
            echo "<script>alert('您输入的登录名称不存在');location.href='/login'</script>";
        }
        $id=$res['id'];
        $red=$bNew->bSj($id);   //u_code信息
        Session::set("ucode",$red);//用户操作信息
        $dtime=strtotime($red['b_dtime']);  //code过期时间
        if(time()<$dtime){
            if($red['b_sta']==0){
                echo "<script>alert('您的账号还未激活点击激活');location.href='/login'</script>";
            $url="https://mail.qq.com/cgi-bin/frame_html";
            $email=$this->bEmail();
            $code=$red['code'];
            $emails=new Email();
          $ids=base64_encode($id);
            $url="http://www.blog.com/home?code=$code&id=$ids";
            $em=$res['b_email'];
            $content="亲爱的".$res['b_showname']."用户您好，请点击激活您的账号".$url;//发送的内容
            $emails->sendMail($em,"乐享博客激活账号",$content);
            }
        }else{
            //重新拉取验证码
            echo "<script>alert('您的验证码已经过期,请重新获取验证码');location.href='/login'</script>";
            if($red['b_sta']==0){
                $url="https://mail.qq.com/cgi-bin/frame_html";
                $email=$this->bEmail();
                $code=md5(time().rand(1,9999));
                $emails=new Email();
                $ids=base64_encode($id);
                $time=base64_encode(time()+60*60*3);
                $url="http://www.blog.com/upcode?code=$code&id=$ids&times=$time";
                $em=$res['b_email'];
                $content="亲爱的".$res['b_showname']."用户您好，请重新获取验证码".$url;//发送的内容
                $emails->sendMail($em,"乐享博客激活账号",$content);
            }
        }
        if($red['b_sta']==1){
            echo "<script>alert('登录成功');location.href='/home'</script>";
        }
    }
    //首页页面
    public function bHome(){
       $userInfo= Session::get("bname");//用户信息
        $data=input("get.");

        if(empty($data)){
            return view("b_home");
        }
        $id=base64_decode($data['id']);
        $bNew=new User();
        $bStasel=$bNew->bselSta($id);
         $uid=$bStasel['uid'];
         if($bStasel['code']==$data['code']){
             $red=$bNew->bActcode($uid);  //激活账号
         }
         $bSl=$bNew->bselSta($id);
        if($bSl['b_sta']==1){
            echo "<script>alert('您的账号已经激活');location.href='/home'</script>";
        }
        if($bStasel['code']!=$data['code']){
            echo "<script>alert('您的验证码已经用过了');location.href='/login'</script>";
        }

        Session::set("code",$bStasel['code']);
    }

    public function bUpCode()
    {
        $data=input("get.");
        $id=base64_decode($data['id']);
        $code=$data['code'];
        $time=base64_decode($data['times']);
        $times=date("Y-m-d:H:i:s",$time);
        $bNew=new User();
        $bStasel=$bNew->bselSta($id);   //查询code信息
        $uid=$bStasel['uid'];
        $newCode=$bNew->bNewcode($uid,$times,$code);
        if($newCode){
            echo "<script>alert('重新获取验证码成功，点击登录');location.href='/home'</script>";
        }
    }
}