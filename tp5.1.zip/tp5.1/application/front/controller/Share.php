<?php
namespace app\front\controller;

use think\Controller;
use think\facade\Session;
use think\facade\Cookie;
use app\front\model\User;
use think\Db;
class Share extends Controller
{
   public function initialize()
    {
        session_start();
    }
    //用户注册页面
    public function bRegister()
    {
         return view("b_register");
    }
    //邮箱
    public function bEmail(){
        include "Email.php";
    }
    //用户注册
    public function bRegdo()
    {
        $bData=input("post.");//接受的数据
        $bse=new User();
         $logname=$bData['b_logname'];
         $b_showname=$bData['b_showname'];
        $bsel=$bse->bUsel($logname);
        Session::set('user',$bsel);
        $bShow=$bse->bShow($b_showname);
        if(empty($bsel)){
              if(empty($bShow)){
                  $bData['b_password']=md5($bData['b_password']);//密码加密
                  $bNew=new User();
                  $res =$bNew->bReg($bData);
                  $code=md5(time().rand(1,9999));//用户注册的code码
                  $time=date("Y-m-d:H:i:s",time());//用户注册的时间
                  $uid=$res;//用户id
                  $dtime=date("Y-m-d:H:i:s",time()+60*60*2);//用户登录的有效期
                  if($res){
                      $red=$bNew->bCode($code,$time,$uid,$dtime);     //添加用户code码
                      echo "<script>alert('注册成功');location.href='/login'</script>";;
                  }else{
                      echo "<script>alert('注册成功');location.href='/reg'</script>";
                  }
              }else{
                  echo "<script>alert('您输入的显示名称已存在');location.href='/reg'</script>";
              }
        }else{
            echo "<script>alert('您输入的登录名称已存在');location.href='/reg'</script>";
        }
    }
    //用户登录页面
    public function bLogin(){
      return view("b_login");
    }
    public function bLogdo()
    {
        $data=input("post.");
        $bNew=new User();
        $logname=$data['b_logname'];
        $res=$bNew->bFel($logname);
        Session::set("bname",$res);//用户信息
        $userid=$res['id'];
        $zanwen=$bNew->bZnwen($userid);//查询此用户是否已经推荐或者反对谋篇文章
        $zanwens=array_column($zanwen,"wen_id"); //文章的id
        Session::set("zenwens",$zanwens);
       if($res['b_snum']==2){
           echo "<script>alert('您的账号已经被封号了');location.href='/login'</script>";
       }
        if(empty($res)){
            echo "<script>alert('您输入的登录名称不存在');location.href='/login'</script>";
        }
        $id=$res['id'];
        $red=$bNew->bSj($id);   //u_code信息
        Session::set("ucode",$red);//用户操作信息
        $dtime=strtotime($red['b_dtime']);  //code过期时间
        if($red['b_sta']==1){
            if(md5($data['b_password'])!=$res['b_password']){
                echo "<script>alert('密码错误');location.href='/login'</script>";
            }
            echo "<script>alert('登录成功');location.href='/home'</script>";
        }
        if(time()<$dtime){
            if($red['b_sta']==0){
                echo "<script>alert('您的账号还未激活点击激活');location.href='/login'</script>";
            $url="https://mail.qq.com/cgi-bin/frame_html";
            $email=$this->bEmail();
            $code=$red['code'];
            $emails=new Email();
          $ids=base64_encode($id);
            $url="http://www.blog.com/home?code=$code&id=$ids";
            $em=$res['b_email'];
            $content="亲爱的".$res['b_showname']."用户您好，请点击激活您的账号".$url;//发送的内容
            $emails->sendMail($em,"乐享博客激活账号",$content);
            }
        }else{
            //重新拉取验证码
            echo "<script>alert('您的验证码已经过期,请重新获取验证码');location.href='/login'</script>";
            if($red['b_sta']==0){
                $url="https://mail.qq.com/cgi-bin/frame_html";
                $email=$this->bEmail();
                $code=md5(time().rand(1,9999));
                $emails=new Email();
                $ids=base64_encode($id);
                $time=base64_encode(time()+60*60*3);
                $url="http://www.blog.com/upcode?code=$code&id=$ids&times=$time";
                $em=$res['b_email'];
                $content="亲爱的".$res['b_showname']."用户您好，请重新获取验证码".$url;//发送的内容
               $d=$emails->sendMail($em,"乐享博客激活账号",$content);
            }
        }

    }
    //首页页面
    public function bHome(){
        $bNew=new User();

        $data=input("get.");//验证码

        if(empty($data)){
//            $name=$_SESSION['think']['bname'];
//            $time=$_SESSION['think']['ucode'];
        }else{
            $id=base64_decode($data['id']);  //激活账号
            $bNew=new User();
            $bStasel=$bNew->bselSta($id);
            $uid=$bStasel['uid'];

            if($bStasel['code']==$data['code']){
                $red=$bNew->bActcode($uid);  //激活账号
            }
            $bSl=$bNew->bselSta($id);
            if($bSl['b_sta']==1){
                $userInfo= Session::get("bname");//用户信息
                $this->assign('user',$userInfo);
                echo "<script>alert('您的账号已经激活');location.href='/home'</script>";
            }
            Session::set("code",$bStasel['code']);
        }
        if(empty($_SESSION['think']['bname'])){
            $res=$bNew->bBloglist();  //未登录状态
            $this->assign('data',$res);
            return view("b_home");

        }else{
            $red =Session::get("bname");
            $id=$red['id'];
//            登录状态
            $sel=$bNew->bImgs($id);

            $this->assign('sel',$sel);
            $up=Session::get('up');//图片
            $this->assign('up',$up);
            $name=$_SESSION['think']['bname'];
            $nameid=$name['id'];      //查询用户的信息
            $names=$bNew->userInfo($id);
            Session::set("names",$names);
            $time=$_SESSION['think']['ucode'];
            $data=$bNew->bBloglist();
//            var_dump($name);die;
            $this->assign('data',$data);
            return view("b_home",['name'=>$name,'time'=>$time,'data'=>$data]);
        }

    }
    //获取新的code
    public function bUpCode()
    {
        $data=input("get.");
        $id=base64_decode($data['id']);
        $code=$data['code'];
        $time=base64_decode($data['times']);
        $times=date("Y-m-d:H:i:s",$time);
        $bNew=new User();
        $bStasel=$bNew->bselSta($id);   //查询code信息
        $uid=$bStasel['uid'];
        $newCode=$bNew->bNewcode($uid,$times,$code);
        if($newCode){
            echo "<script>alert('重新获取验证码成功，点击登录');location.href='/login'</script>";
        }
    }
    //退出登录
    public function bQuit()
    {
        $d=$_SESSION["think"]=array();
        if(empty($d)){
           return $this->redirect("/login");
        }
    }
    //忘记密码页
    public function bWpwd()
    {
         return view("b_pwd");
    }
    //找回密码
    public function bZpwd()
    {
        $logName=input("post.b_logname");
        $bNew=new User();
        $zPwd=$bNew->bZpwd($logName);//查询用户的信息
        $this->assign("users",$zPwd);
        $id=$zPwd['id'];
        $zPsta=$bNew->bselSta($id);    //code
        $this->assign("code",$zPsta);
        return view("b_zpwd");
    }
    //重置密码
    public function bXpwd()
    {
        $bId=input("post.id");
        $bPwd=input("post.b_password");
        $bCode=input("post.code");
        $bNew=new User();
        $email=$this->bEmail();
        echo "<script>alert('提交成功');location.href='/login'</script>";
        $emails=new Email();
        $ids=base64_encode($bId);
        $bPwd=md5($bPwd);
        $url="http://www.blog.com/bfix?code=$bCode&id=$ids&pwd=$bPwd";
       $res= Session::get("bname");//用户信息
        $em=$res['b_email'];
        $content="亲爱的".$res['b_showname']."用户您好，请点击修改您的密码 ".$url;//发送的内容
        $emails->sendMail($em,"乐享博客",$content);
    }
    //修改密码
    public function bFixpwd()
    {
        $data=input("get.");
        if(empty($data)){
            echo "<script>alert('数据异常'),location.href='/login'</script>";
        }else{
            $id=base64_decode($data['id']);
            $code=$data['code'];
            $pwd=$data['pwd'];
            $bNew=new User();
            $zPsta=$bNew->bselSta($id);    //code
            if($code==$zPsta['code']){
                $reg=$bNew->bXpwd($id,$pwd);
                if($reg){
                    echo "<script>alert('成功修改密码,点击去登录'),location.href='/login'</script>";
                }
            }
        }
    }
    //添加头像
    public function bImg()
    {
        $id=$_GET['id'];
        $this->assign('id',$id);
        return view("b_img");
    }
    public function bPic()
    {
        $id=$_POST['id'];
        $file=$_FILES['file'];
        $filename="E:\phpstudy\PHPTutorial\WWW\share/tp5.1/public/upload/".$file['name'];//图片
        $imgs="http://www.blog.com/upload/".$file['name'];
        move_uploaded_file($file['tmp_name'],$filename);
        $bNew=new User();
        $bImg=$bNew->biMg($imgs,$id);
        if($bImg){
            echo "<script>alert('上传成功');location.href='/'</script>";
        }else{
            echo "<script>alert('上传失败');location.href='/'</script>";
        }
        $up=$bNew->bImgs($id);

         Session::set('up',$up);
    }
    //写博文页面
    public function bRewrite()
    {
        $user= Session::get('bname');
        if(empty($user)){
            echo "<script>alert('您还没有登录');location.href='/'</script>";
        }
       return view("b_rewrite");
    }
    //写博文
    public function bWrite()
    {
       $user= Session::get('bname');
       if(empty($user)){
           echo "<script>alert('您还没有登录');location.href='/'</script>";
       }
        $data=input("post.");
        $data['b_text']=$data['b_text'][0];
        $data['b_createtime']=date("Y-m-d:H:i:s",time());//当前时间
        $data['userid']=$user['id'];//作者
        $bNew=new User();
        $bWblog=$bNew->bWblog($data);
        if($bWblog){
           echo json_encode(['code'=>200,'msg'=>'发布成功']);die;
        }else{
            echo json_encode(['code'=>4001,'msg'=>'发布失败']);
        }
    }
    //博文正文
    public function bShowblog()
    {
        if(empty($_GET['id'])){
            echo "<script>alert('数据异常');location.href='/home'</script>";
            echo json_encode(['code'=>404,'msg'=>'请先登录 ']);die;
        }

        if(empty($_SESSION['think']['bname'])){
            if(empty($_SESSION['think']['ucode'])){
                $id=$_GET['id'];        //查询的id
                $bNew=new User();
                $blogCon=$bNew->bBlogcon($id);  //博客正文
//                $name=$_SESSION['think']['bname'];
                $blist=$bNew->bD($id);//三条
                $data=$bNew->bCd($id);//全部
                $count=count($data);
                $up =Session::get('up');

                return view("b_blogcontent",['id'=>$id,'up'=>$up,'blog'=>$blogCon,'count'=>$count,'blist'=>$blist,'data'=>$data]);
            }
        }else{
            $id=$_GET['id'];        //查询的id
            $bNew=new User();
            $blogCon=$bNew->bBlogcon($id);  //博客正文
             $pv=$blogCon['b_pv'];                  //pv
            $b_pv=$bNew->bPv($id,$pv);
            $blogs=$bNew->bBlogcon($id);  //博客正文
            Session::set("high",$blogs);
            $name=$_SESSION['think']['bname'];
            $names=Session::get("names");
            $blist=$bNew->bD($id);//三条评论
            $userid=$name['id'];   //用户id

            $bNew->zanInfo();
            $data=$bNew->bCd($id);//全部
            $bid= $blogs['b_id'];//文章id
//            $zen=Session::get("zenwens");//用户是否推荐
            $userid=$names['id'];
            $zent=$bNew->bZnwen($userid);
            $zen=array_column($zent,"wen_id");
              $zens=in_array($bid,$zen);
             $vs=$bNew->bZa($id);
            $count=count($data);
            $up =Session::get('up');
            $time=$_SESSION['think']['ucode'];
            return view("b_blogcontent",['id'=>$id,'name'=>$names,'time'=>$time,'up'=>$up,'blog'=>$blogs,'count'=>$count,'blist'=>$blist,'data'=>$data,'zen'=>$zens,'vs'=>$vs]);
        }
    }
    //评论
    public function bComent()
    {
        if(empty($_POST['id'])){
            echo json_encode(['code'=>404,'msg'=>'请先登录 ']);die;
        }
       $ref= Session::get("bname");//用户信息
        Db::startTrans();//开启事务
          $data=input("post.");
         $id=$data['id'];//用户的id
         $ids=$data['ids'];//文章的b_id
        $coment=$data['con'];//评论的内容
         $con=$data['b_con'];//评论的数量
         $time=date("Y-m-d:H:i:s",time());
         $name=$ref['b_showname'];
         $img=$ref['b_pic'];
        $bNew=new User();
        $red=['b_uid'=>$id,'b_content'=>$coment,'b_ptime'=>$time,'b_artid'=>$ids,'b_names'=>$name,'b_img'=>$img];//当前时间
        $coment=$bNew->bComent($red); //添加评论的内容
        $text=$bNew->bText($ids,$con);
        if($coment==false||$text==false){
            Db::rollback();
            echo json_encode(['code'=>4001,'msg'=>'发表失败']);die;
        }else{
            Db::commit();
            echo json_encode(['code'=>200,'msg'=>'发表成功']);die;
        }
    }

    //顶
    public function bZan()
    {
         if(empty($_POST)){
             echo json_encode(['code'=>404,'msg'=>'数据异常']);die;
         }
        $bNew=new User();
         $data=input("post.");
        $b_id=$data['id'];//文章的id
        $id=$data['ids'];//用户的id
           $zan_nums=$bNew->bZn($b_id);   //查询赞的数量
            $zan_num=$zan_nums['b_zannum'];
       $red=['user_id'=>$id,'wen_id'=>$b_id,'zan_sta'=>1]; //添加到关联表
          $bAdd= $bNew->bZanart($red);
        if($bAdd){
            $bNew->bUpzan($b_id,$zan_num);
            echo json_encode(['code'=>200,'msg'=>'支持成功']);die;
        }else{
            echo json_encode(['code'=>40001,'msg'=>'支持失败']);die;
        }
    }
    //反对||踩
    public function oppOse()
    {
        if(empty($_POST)){
            echo json_encode(['code'=>404,'msg'=>'数据异常']);die;
        }
        $bNew=new User();
        $data=input("post.");
        $b_id=$data['id'];//文章的id
        $id=$data['ids'];//用户的id
        $fanums=$bNew->bCn($b_id);
        $b_fannums=$fanums['b_fannums'];//查询踩的数量
        $red=['user_id'=>$id,'wen_id'=>$b_id,'zan_sta'=>2]; //添加到关联表
         $bLow= $bNew->bZanart($red);
        if($bLow){
             $bNew->bUpcai($b_fannums,$b_id);
            echo json_encode(['code'=>200,'msg'=>'反对成功']);die;
        }else{
            echo json_encode(['code'=>40001,'msg'=>'反对失败']);die;
        }
    }
}